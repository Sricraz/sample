import React from 'react';
import './withAuthentication.css';

const withAuthentication = (WrappedComponent) => {
  return class extends React.Component {
    render() {
      const { isAuthenticated, ...otherProps } = this.props;
      if (isAuthenticated) {
        return <WrappedComponent {...otherProps} />;
      } else {
        return <div className="auth-message">Authentication is required to view this content.</div>;
      }
    }
  };
};

export default withAuthentication;
