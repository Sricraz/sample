// src/UserProfile.js
import React from 'react';
import './UserProfile.css';

const UserProfile = ({ name, email }) => {
  return (
    <div className="user-profile">
      <h1>User Profile</h1>
      <p>Name: {name}</p>
      <p>Email: {email}</p>
    </div>
  );
};

export default UserProfile;
