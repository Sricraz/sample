import React from 'react';
import UserProfile from './UserProfile';
import withAuthentication from './withAuthentication';
import './App.css';

const AuthenticatedUserProfile = withAuthentication(UserProfile);

const App = () => {
  const isAuthenticated = false; 
  return (
    <div className="app">
      <AuthenticatedUserProfile isAuthenticated={isAuthenticated} name="Sriyamini" email="sriyamini.jayakrishnan@xebia.com" />
    </div>
  );
};

export default App;
